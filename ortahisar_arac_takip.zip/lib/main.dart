import 'package:flutter/material.dart';

void main() {
  runApp(const OrtahisarAracTakipApp());
}

class OrtahisarAracTakipApp extends StatelessWidget {
  const OrtahisarAracTakipApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ortahisar Araç Takip',
      home: Scaffold(
        appBar: AppBar(title: const Text('Ortahisar Araç Takip')),
        body: const Center(child: Text('Araç Takip Sistemine Hoş Geldiniz')),
      ),
    );
  }
}
